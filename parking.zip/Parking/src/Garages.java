import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.sql.*;
import java.util.logging.*;






public class Garages extends JFrame  {
	private JPanel contentPane;
	
	int[] pKGarage = new int [500];
	int[] pkSlot = new int[500];
	int[] reservedPkSlots = new int[500];
	int kundeID;
	
    JComboBox comboShowGarages = new JComboBox();
	JComboBox ComboSelectSlots = new JComboBox();
	JComboBox comboDisplayReserved = new JComboBox();
	
	JButton btnBook = new JButton("Book");
    JButton btnGarageList = new JButton("List of garages");
    private final JButton btncheckOut = new JButton("Check out");
    JLabel lblTitleCheckIn = new JLabel("You can book your parking slot here");
    JLabel lblTitleCheckOut = new JLabel("You can check out from here");
    JLabel lblDisplayGarages = new JLabel("Click to display garages");
	JLabel lblChooseOne = new JLabel("Choose one");
	JLabel lblSelectSlots = new JLabel("Select slots");
	JLabel lblConfirmBooking = new JLabel("Confirm booking");
	JLabel lblDisplayBookedSlots = new JLabel("Display booked slots");
	JLabel lblCheckOut = new JLabel("Click to check out");
	
	Connection con;
	
	
	/**
	 * Launch the application.
	 */	
	
	
	
	
	/**
	 * Create the frame.
	 */
	
	
	
	public Garages() {
		initializeFrame();
		createConnection();	
		findMaxID();
		
		

	}
	
	public void openNewFrame() {

	}

	public void initializeFrame() {
		
		
		setBackground(new Color(240, 230, 140));
		setForeground(Color.BLACK);
		setTitle("Garages");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(500,500);
		//setBounds(100, 100, 992, 675);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 230, 140));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridwidth = 2; 
		gbc.gridx = 0;
		gbc.gridy = 0;                    
		lblTitleCheckIn.setFont(new Font("Pluto", Font.BOLD, 18));
		lblTitleCheckIn.setForeground(new Color(0, 115, 0));
	    contentPane.add(lblTitleCheckIn, gbc);
		
		gbc.insets = new Insets(10,0,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		gbc.gridy = 1;
		contentPane.add(lblDisplayGarages, gbc);
		//
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridx = 2;
		gbc.gridy = 1;
		contentPane.add(btnGarageList, gbc);
		//
		gbc.insets = new Insets(10,0,0,0);
		gbc.gridx = 0;
		gbc.gridy = 2;
		contentPane.add(lblChooseOne, gbc);
		//
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridx = 2;
		gbc.gridy = 2;
		contentPane.add(comboShowGarages, gbc);
		//#
		gbc.insets = new Insets(10,0,0,0);
		gbc.gridx = 0;
		gbc.gridy = 3;
		contentPane.add(lblSelectSlots, gbc);
		//
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridx = 2;
		gbc.gridy = 3;
		contentPane.add(ComboSelectSlots, gbc);
		//
		gbc.insets = new Insets(10,0,0,0);
		gbc.gridx = 0;
		gbc.gridy = 4;
		contentPane.add(lblConfirmBooking, gbc);
		//#
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridx = 2;
		gbc.gridy = 4;
		contentPane.add(btnBook, gbc);
		
		gbc.insets = new Insets(10,0,0,0);
		gbc.gridwidth = 2;
		gbc.gridx = 0;
		gbc.gridy = 5;
		lblTitleCheckOut.setFont(new Font("Pluto", Font.BOLD, 18));
		lblTitleCheckOut.setForeground(new Color(255, 0, 0));
		contentPane.add(lblTitleCheckOut, gbc);
		
		//
		gbc.gridwidth = 1;
		gbc.insets = new Insets(10,0,0,0);
		gbc.gridx = 0;
		gbc.gridy = 6;
		contentPane.add(lblDisplayBookedSlots, gbc);
		//
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridx = 2;
		gbc.gridy = 6;
		contentPane.add(comboDisplayReserved, gbc);
		//
		gbc.insets = new Insets(10,0,0,0);
		gbc.gridx = 0;
		gbc.gridy = 7;
		contentPane.add(lblCheckOut, gbc);
		//
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridx = 2;
		gbc.gridy = 7;
		contentPane.add(btncheckOut, gbc);

	    
	
		
		
	
		
		
		
		
		
		btnBook.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
			    provideTicket();
				submit();
				showParkingSlots();
				showReserved();
				
				} catch(Exception es ) {
					JOptionPane.showMessageDialog(null, "Please select your desired garage first!");
				
				}
			}		
		});
		comboShowGarages.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				
				ComboSelectSlots.removeAllItems();
				showParkingSlots();
				
			}
		});
	
		
		btnGarageList.addActionListener(new ActionListener() {
	 	public void actionPerformed(ActionEvent e) {
	 		try {
				comboShowGarages.removeAllItems();
				
				showGarage();
	 		} catch(java.lang.ArrayIndexOutOfBoundsException ex) {
	 			JOptionPane.showMessageDialog(null, "Please don't click this button again, for the love of God ");
	 		}
				
					
				
			}
		}
	
		);
		
		
		comboDisplayReserved.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				
			}
		});
			
		btncheckOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				checkOut();
				showParkingSlots();
				} catch(Exception em) {
					JOptionPane.showMessageDialog(null, "You need to book first, before you can check out!");
				}
				}
		});
	


	}
	
		
	/*We were unable to retrieve the Kunde_ID from the RegisteredGUI class, so we were forced to
	 * come up with a method that gets hold of the maximum Kunde_ID, which can later be used as a foreign key in 
	 * other tables. 
	 */
	public int findMaxID() {
		try {
	        String sql = "SELECT MAX(Kunde_ID) from parking.kunde"; 	
		    Statement pst = con.prepareStatement(sql);
		    ResultSet rs = pst.executeQuery(sql);
		    while(rs.next()) {
		    String add1 = rs.getString("max(Kunde_ID)");
			System.out.println(add1);
			kundeID = Integer.parseInt(add1);
			
			
		} 
		}
		catch (SQLException e) 
		{
			JOptionPane.showMessageDialog(null, e);
		}
		return kundeID;
		
		
	}
	//Once this method is called, it'll show a list of garages that can be selected by the customer.
    public void showGarage() {
    	try {
    	Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * FROM parking.garage");
	    int i = 0;
		while(rs.next()) {
			String adresse = rs.getString("name");
			String adresse1 = rs.getString("Adresse_ID"); 
			pKGarage[i] = rs.getInt("Garage_ID");
			comboShowGarages.addItem(adresse + " "  + adresse1 + " " + pKGarage[i]);
            i++;
          
          // input.getSelectedItem();
        //    System.out.println(input.getSelectedItem());
	}
		
		System.out.println("Database connection successful");
    	}
    	catch(SQLException eq){
    
    	}
    	
    }
	
   //All parking slots can be displayed once this method is called on the action listener.
    public void showParkingSlots() {
    	try {
    		
    		ComboSelectSlots.removeAllItems();
    		int c = comboShowGarages.getSelectedIndex();
        	int garage_ID  = pKGarage[c];
        	Statement stmt = con.createStatement();
     		ResultSet rs = stmt.executeQuery("SELECT * FROM parking.Parking_Slot WHERE Garage_ID =   '" + garage_ID +"' AND reserved = false ;");
            int j = 0; 	
    		while(rs.next()) {	
    		String slot = rs.getString("SLOT_Nr");
    	    pkSlot[j] = rs.getInt("PK_Slot_ID");
    		
    		ComboSelectSlots.addItem(slot);
    		j++;
    		}
    	
    	
    	
    	}
    	catch (SQLException eq) {
    		JOptionPane.showMessageDialog(null, eq);
    	}
    	
    		
    }
       //This method provides the customer with the ticket. 
	    public void provideTicket() {
	    	try {
	    		
	    		int c = ComboSelectSlots.getSelectedIndex();
	    		int kunde_ID = kundeID;
	    		int d = ComboSelectSlots.getSelectedIndex();
	    		int parkingslot_ID = pkSlot[d];
	    		String ticketNumber = Integer.toString(kunde_ID) +"-"+ Integer.toString(parkingslot_ID );
	    		PreparedStatement stmt = con.prepareStatement("Insert into parking.Ticket (Kunde_ID, PK_Slot_ID, Ticketnr) VALUES (?,?,?);");
	    		
	    		stmt.setInt(1, kunde_ID);
	            stmt.setInt(2, parkingslot_ID);
	            stmt.setString(3, ticketNumber);
	           	stmt.executeUpdate();
	    	     
	           	String confirmation = "Slot is booked. Your ticket number is " + ticketNumber;
	           	JOptionPane.showMessageDialog(null, confirmation);
	    	  
	    	}
	    	catch(SQLException es) { 
	    	JOptionPane.showMessageDialog(null, es);
	    		
	    	}
	    }	
	   
	   //This method reserves whatever parking slot the customer had chosen.
    public void submit() {
    	try {
    	int c = ComboSelectSlots.getSelectedIndex();
    	int pkSlot_ID = pkSlot[c];
    	PreparedStatement stmt = con.prepareStatement("UPDATE parking.parking_slot set reserved = TRUE WHERE PK_Slot_ID = '" + pkSlot_ID +"';");
    	stmt.executeUpdate();
   	} catch(SQLException es) {
    		JOptionPane.showMessageDialog(null, es);
    	}
    }
	   //This method is responsible for showing all the reserved slots. 
    public void showReserved() {
    	try {
    		comboDisplayReserved.removeAllItems();	
    	String slotNr;
    	PreparedStatement stmt = con.prepareStatement("SELECT * FROM parking.parking_slot WHERE reserved = TRUE ;");
    	ResultSet rs = stmt.executeQuery();
    	int i = 0;
    	while(rs.next()) {
    		slotNr = rs.getString("SLOT_Nr");
    		reservedPkSlots[i] = rs.getInt("PK_Slot_ID");
    		comboDisplayReserved.addItem(slotNr);
    		i++;
    	}
    	
    	} catch(SQLException es) {
    		JOptionPane.showMessageDialog(null, es);
    	}
    }
    
    //This method enables the customer to check out from the parking.
    public void checkOut() {
    	try {
    		
    	
    	int c = comboDisplayReserved.getSelectedIndex();
    	int pkSlot_ID  = reservedPkSlots[c];
    	PreparedStatement stmt = con.prepareStatement("UPDATE parking.parking_slot set reserved = FALSE WHERE PK_Slot_ID = '" + pkSlot_ID +"';");
    	stmt.executeUpdate();
    	showReserved();
    	} catch(SQLException es) {
    		JOptionPane.showMessageDialog(null, es);
    	}
    	}
    
    //This method creates the connection between the database and java using the JDBC driver.
	public void createConnection() 
	{
		try {
		Class.forName("com.mysql.cj.jdbc.Driver"); 
		
	    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/parking", "root","root");
		}catch (ClassNotFoundException ex) {
			Logger.getLogger(Garages.class.getName()).log(Level.SEVERE, null, ex);
		}
		catch (SQLException ex) {
		    Logger.getLogger(Garages.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	
	//This method closes the window 
	public void close() {
		WindowEvent closeWindow = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
		java.awt.Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}
	
	public static void main(String[] args) {
		    
		   	Garages frame = new Garages();
		
			frame.setVisible(true);
		
}
}

	


