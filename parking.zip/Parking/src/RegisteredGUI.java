import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;



import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.*;
import java.awt.event.ActionEvent;

public class RegisteredGUI extends JFrame implements Serializable {

	JLabel lblNachname = new JLabel("Nachname");
	JLabel lblVorname = new JLabel("Vorname");
	JLabel lblStrasse = new JLabel("Strasse");
	JLabel lblWohnort = new JLabel("Wohnort");
	JLabel lblPlz = new JLabel("Postleitzahl");
	
	JLabel lblWelcome = new JLabel("Welcome to our parking");
	
	JButton btnReset = new JButton("Reset");
	JButton btnSave = new JButton("Save");
	
	private JPanel contentPane;
	private JTextField inputNachname = new JTextField();
	private JTextField inputVorname = new JTextField();
	private JTextField inputStrasse = new JTextField();
	private JTextField inputWohnort = new JTextField();
	private JTextField inputPlz = new JTextField(); 
    private int adresseID; 
    private int kundeID;
    Connection con;

    
 
    

	/**
	 * Launch the application.
	 */
	
    public static void main(String[] args) throws IOException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisteredGUI frame = new RegisteredGUI();
					
					frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	   }); 
		
	}
	/**
	 * Create the frame.
	 */
	
	public RegisteredGUI() {
		intitializeFrame();
		createConnection();
	}
	
	public void intitializeFrame() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(500,500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(244, 164, 96));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
	    contentPane.setLayout(new GridBagLayout());
		
	    GridBagConstraints gbc = new GridBagConstraints();
		
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridwidth = 2;
		gbc.gridx = 0;
		gbc.gridy = 0;
		lblWelcome.setFont(new Font("Tahoma", Font.BOLD, 18));
		contentPane.add(lblWelcome, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		gbc.gridy = 1;
		contentPane.add(lblVorname, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 1;
		gbc.gridy = 1;
		contentPane.add(inputVorname, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 2;
		gbc.gridy = 1;
		contentPane.add(btnReset, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 3;
		gbc.gridy = 1;
		contentPane.add(btnSave, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		gbc.gridy = 2;
		contentPane.add(lblNachname, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 1;
		gbc.gridy = 2;
		contentPane.add(inputNachname, gbc);
	
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		gbc.gridy = 3;
		contentPane.add(lblStrasse, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 1;
		gbc.gridy = 3;
		contentPane.add(inputStrasse, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		gbc.gridy = 4;
		contentPane.add(lblWohnort, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 1;
		gbc.gridy = 4;
		contentPane.add(inputWohnort, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		gbc.gridy = 5;
		contentPane.add(lblPlz, gbc);
		
		gbc.insets = new Insets(10,10,0,0);
		gbc.gridwidth = 1;
		gbc.gridx = 1;
		gbc.gridy = 5;
		contentPane.add(inputPlz, gbc);
		

	
		
		btnSave.addActionListener(new ActionListener() {
			 
			public void actionPerformed(ActionEvent e) {
	       //JOptionPane.showMessageDialog(btnNewButton, "Registered successfully");
				if(inputNachname.getText().isEmpty() || inputVorname.getText().isEmpty() || inputStrasse.getText().isEmpty() || inputWohnort.getText().isEmpty() || inputPlz.getText().isEmpty() ) {
					JOptionPane.showMessageDialog(null, "Please fill all of the fields");
                	
				}
				
				else {
					System.out.println(Integer.toString(getKundeID()));
					 registerAddress();
					 registerKundeID();
					 getKundeID();
				     close();
			       
				    
				} 
	       }
		});
		
		
	}
	
	public int getAdresseID() {
		return adresseID;
	}
	
	public int getKundeID() {
		return kundeID;
	}
	//Closes this frame and then refers us to the garage frame.
	public void close() {
		WindowEvent closeWindow = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
		java.awt.Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(closeWindow);
	}
	
	//This method enables us to insert all the prerequisite address information from java to mysql.
	public void registerAddress() {
	
		try {
			
			
			
			String strasse = inputStrasse.getText();
			String wohnort = inputWohnort.getText();
			String postleitzahl = inputPlz.getText();

			
			String query2 = "INSERT INTO parking.adresse(Strasse, Wohnort, Postleitzahl) VALUES ('" +strasse +  " ',' " + wohnort +  " ',' "  +  postleitzahl + "')";
			
				
				  Statement stmt = con.createStatement();
				  stmt.executeUpdate(query2, Statement.RETURN_GENERATED_KEYS);
		    
		      //Retrieving the auto-generated (auto-incremented) keys
			  	ResultSet rs = stmt.getGeneratedKeys();
		    
			     while(rs.next()) {
			     adresseID = rs.getInt(1);
			     
		     
		     getAdresseID();
		      }
		     
		  } catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
	
    }
	
	//This method enables us to insert all the prerequisite customer information from java to mysql.
	public void registerKundeID() {
		int adresse = getAdresseID();
		try { 
			
		String nachname = inputNachname.getText();
	    String vorname = inputVorname.getText();
	    

	    Statement stmt = con.createStatement();
	    String dbop =  "INSERT INTO parking.kunde(name,  vorname, Adresse_ID) VALUES ('"+ nachname + " ',' " + vorname + " ',' " + adresse +"')";
	 
	    stmt.executeUpdate(dbop, Statement.RETURN_GENERATED_KEYS);
	    ResultSet ls = stmt.getGeneratedKeys(); 
	    while(ls.next()) {
       	kundeID = ls.getInt(1);
       
         }
	
	    close();
        Garages gs = new Garages();
        gs.setVisible(true);
	
		} catch (SQLException e1) {
	// TODO Auto-generated catch block
	    e1.printStackTrace();
	
       }
 
	}
	
	public void reset() {
		inputNachname.setText(null);
        inputVorname.setText(null);
        inputStrasse.setText(null);
        inputWohnort.setText(null);
        inputPlz.setText(null);
    }
	//Creates the connection between java and mysql using JDBC driver.
	public void createConnection() 
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/parking", "root","root");
			
		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Garages.class.getName()).log(Level.SEVERE, null, ex);
			
		} catch (SQLException ex) {
		    Logger.getLogger(Garages.class.getName()).log(Level.SEVERE, null, ex);
		}
   }
	
	
}
